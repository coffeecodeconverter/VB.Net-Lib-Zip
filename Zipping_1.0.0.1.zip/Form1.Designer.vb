﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button_Zip = New System.Windows.Forms.Button()
        Me.Button_Unzip = New System.Windows.Forms.Button()
        Me.ComboBox_OutputFolder = New System.Windows.Forms.ComboBox()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.Button_SelectFolder = New System.Windows.Forms.Button()
        Me.Button_SelectFiles = New System.Windows.Forms.Button()
        Me.ListBox_InputFiles = New System.Windows.Forms.ListBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Button_Clear_Output = New System.Windows.Forms.Button()
        Me.Button_Clear_Input = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Button_Zip
        '
        Me.Button_Zip.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_Zip.Location = New System.Drawing.Point(548, 386)
        Me.Button_Zip.Name = "Button_Zip"
        Me.Button_Zip.Size = New System.Drawing.Size(83, 23)
        Me.Button_Zip.TabIndex = 0
        Me.Button_Zip.Text = "Zip"
        Me.Button_Zip.UseVisualStyleBackColor = True
        '
        'Button_Unzip
        '
        Me.Button_Unzip.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_Unzip.Location = New System.Drawing.Point(637, 386)
        Me.Button_Unzip.Name = "Button_Unzip"
        Me.Button_Unzip.Size = New System.Drawing.Size(83, 23)
        Me.Button_Unzip.TabIndex = 1
        Me.Button_Unzip.Text = "UnZip"
        Me.Button_Unzip.UseVisualStyleBackColor = True
        '
        'ComboBox_OutputFolder
        '
        Me.ComboBox_OutputFolder.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.ComboBox_OutputFolder.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.ComboBox_OutputFolder.FormattingEnabled = True
        Me.ComboBox_OutputFolder.Location = New System.Drawing.Point(12, 351)
        Me.ComboBox_OutputFolder.Name = "ComboBox_OutputFolder"
        Me.ComboBox_OutputFolder.Size = New System.Drawing.Size(619, 21)
        Me.ComboBox_OutputFolder.TabIndex = 3
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.ProgressBar1.Location = New System.Drawing.Point(12, 395)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(85, 14)
        Me.ProgressBar1.TabIndex = 4
        '
        'Button_SelectFolder
        '
        Me.Button_SelectFolder.Location = New System.Drawing.Point(12, 322)
        Me.Button_SelectFolder.Name = "Button_SelectFolder"
        Me.Button_SelectFolder.Size = New System.Drawing.Size(83, 23)
        Me.Button_SelectFolder.TabIndex = 6
        Me.Button_SelectFolder.Text = "Select Folder"
        Me.Button_SelectFolder.UseVisualStyleBackColor = True
        '
        'Button_SelectFiles
        '
        Me.Button_SelectFiles.Location = New System.Drawing.Point(12, 77)
        Me.Button_SelectFiles.Name = "Button_SelectFiles"
        Me.Button_SelectFiles.Size = New System.Drawing.Size(83, 23)
        Me.Button_SelectFiles.TabIndex = 5
        Me.Button_SelectFiles.Text = "Select Files"
        Me.Button_SelectFiles.UseVisualStyleBackColor = True
        '
        'ListBox_InputFiles
        '
        Me.ListBox_InputFiles.FormattingEnabled = True
        Me.ListBox_InputFiles.Location = New System.Drawing.Point(12, 106)
        Me.ListBox_InputFiles.Name = "ListBox_InputFiles"
        Me.ListBox_InputFiles.Size = New System.Drawing.Size(707, 186)
        Me.ListBox_InputFiles.TabIndex = 7
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 55)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(31, 13)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "Input"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(13, 304)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(39, 13)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "Output"
        '
        'Button_Clear_Output
        '
        Me.Button_Clear_Output.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_Clear_Output.Location = New System.Drawing.Point(637, 350)
        Me.Button_Clear_Output.Name = "Button_Clear_Output"
        Me.Button_Clear_Output.Size = New System.Drawing.Size(82, 23)
        Me.Button_Clear_Output.TabIndex = 10
        Me.Button_Clear_Output.Text = "Clear"
        Me.Button_Clear_Output.UseVisualStyleBackColor = True
        '
        'Button_Clear_Input
        '
        Me.Button_Clear_Input.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_Clear_Input.Location = New System.Drawing.Point(638, 77)
        Me.Button_Clear_Input.Name = "Button_Clear_Input"
        Me.Button_Clear_Input.Size = New System.Drawing.Size(82, 23)
        Me.Button_Clear_Input.TabIndex = 11
        Me.Button_Clear_Input.Text = "Clear"
        Me.Button_Clear_Input.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(742, 24)
        Me.MenuStrip1.TabIndex = 12
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(742, 421)
        Me.Controls.Add(Me.Button_Clear_Input)
        Me.Controls.Add(Me.Button_Clear_Output)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.ListBox_InputFiles)
        Me.Controls.Add(Me.Button_SelectFolder)
        Me.Controls.Add(Me.Button_SelectFiles)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.ComboBox_OutputFolder)
        Me.Controls.Add(Me.Button_Unzip)
        Me.Controls.Add(Me.Button_Zip)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button_Zip As Button
    Friend WithEvents Button_Unzip As Button
    Friend WithEvents ComboBox_OutputFolder As ComboBox
    Friend WithEvents ProgressBar1 As ProgressBar
    Friend WithEvents Button_SelectFolder As Button
    Friend WithEvents Button_SelectFiles As Button
    Friend WithEvents ListBox_InputFiles As ListBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Button_Clear_Output As Button
    Friend WithEvents Button_Clear_Input As Button
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As ToolStripMenuItem
End Class
