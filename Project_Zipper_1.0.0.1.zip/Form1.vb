﻿


Imports System.ComponentModel
Imports System.IO
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class Form1


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub




    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
    End Sub





    Private Sub Button_Clear_Output_Click(sender As Object, e As EventArgs) Handles Button_Clear_Output.Click
        ComboBox_OutputFolder.Text = ""
    End Sub

    Private Sub Button_Clear_Input_Click(sender As Object, e As EventArgs) Handles Button_Clear_Input.Click
        ListBox_InputFiles.Items.Clear()
    End Sub







    Private Sub Button_SelectFiles_Click(sender As Object, e As EventArgs) Handles Button_SelectFiles.Click
        Dim files = SelectFiles(True, "All files (*.*)|*.*", "Select files to ZIP")
        If files.Any() Then
            'MessageBox.Show("Files selected:" & vbCrLf & String.Join(Environment.NewLine, files))
            ListBox_InputFiles.Items.Clear()
            ListBox_InputFiles.Items.AddRange(files.ToArray())
        Else
            MessageBox.Show("No files selected.")
        End If
    End Sub







    Private Sub Button_SelectFolder_Click(sender As Object, e As EventArgs) Handles Button_SelectFolder.Click
        Dim folder = SelectFolder("Select extraction folder")
        If Not String.IsNullOrWhiteSpace(folder) Then
            'MessageBox.Show("Folder selected: " & folder)

            ' Add to ComboBox if not already in the list
            If Not ComboBox_OutputFolder.Items.Contains(folder) Then
                ComboBox_OutputFolder.Items.Add(folder)
            End If
            ' Select the current folder in the combo box
            ComboBox_OutputFolder.SelectedItem = folder
        Else
            MessageBox.Show("No folder selected.")
        End If
    End Sub








    Private Async Sub Button_Zip_Click(sender As Object, e As EventArgs) Handles Button_Zip.Click
        Dim zipProgress = New Progress(Of Integer)(Sub(p) ProgressBar1.Value = p)

        Dim items As IEnumerable(Of String) = ListBox_InputFiles.Items.Cast(Of String)()

        ' If the listbox is empty, just let ZipAsync ask the user
        If Not items.Any() Then
            items = Nothing
        End If

        Dim zipPath As String = ""
        If String.IsNullOrWhiteSpace(ComboBox_OutputFolder.Text) Then
            zipPath = Nothing
        Else
            zipPath = Path.Combine(ComboBox_OutputFolder.Text, TextBox_Output_Filename.Text)
        End If

        '' SIMPLEST
        ''Dim result As String = Await ZipAsync(progress:=progress)

        '' or Passing the arguments
        Dim result As String = Await ZipAsync(items, zipPath, zipProgress)

        If result.ToLower().Contains("error") OrElse result.ToLower().Contains("failed") Then
            MessageBox.Show("Zipping failed: " & result, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            MessageBox.Show(result, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If

        ProgressBar1.Value = 0
    End Sub





    Private Async Sub Button_Unzip_Click(sender As Object, e As EventArgs) Handles Button_Unzip.Click

        ' Allow 0, as it then gets handled in the unzip function anyway 
        If ListBox_InputFiles.SelectedItems.Count > 1 Then
            MessageBox.Show("Please select exactly one ZIP file from the list.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        If ListBox_InputFiles.SelectedItems.Count = 0 Then
            MessageBox.Show("No File selected to UnZip - Browse for one", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If

        Dim selectedPath As String = TryCast(ListBox_InputFiles.SelectedItem, String)

        Dim zipProgress = New Progress(Of Integer)(Sub(p) ProgressBar1.Value = p)

        ' SIMPLEST
        ' Dim result As String = Await UnzipAsync(progress:=progress)

        ' or Passing the arguments
        Dim result As String = Await UnzipAsync(selectedPath, ComboBox_OutputFolder.Text, zipProgress)

        If result.ToLower().Contains("error") OrElse result.ToLower().Contains("failed") Then
            MessageBox.Show("Unzipping failed: " & result, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            MessageBox.Show(result, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If

        ProgressBar1.Value = 0



        'Dim filesToUnzip As IEnumerable(Of String) = ListBox_InputFiles.Items.Cast(Of String)()

        '' If the listbox is empty, let UnzipAsync prompt the user
        'If Not filesToUnzip.Any() Then
        '    filesToUnzip = Nothing
        'End If

        'If filesToUnzip Is Nothing Then
        '    MessageBox.Show("Please select exactly one ZIP file from the list.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        '    Exit Sub
        'ElseIf filesToUnzip.Count > 1 Then
        '    MessageBox.Show("Please select exactly one ZIP file from the list.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        '    Exit Sub
        'End If



        'Dim zipProgress = New Progress(Of Integer)(Sub(p) ProgressBar1.Value = p)

        '' Set output directory path
        'Dim outputFolder As String = ComboBox_OutputFolder.Text
        'If String.IsNullOrWhiteSpace(outputFolder) Then
        '    outputFolder = Nothing ' Let UnzipAsync prompt
        'End If

        ''' SIMPLEST
        ''' Dim result As String = Await UnzipAsync(progress:=progress)

        ''' or Passing the arguments
        'Dim result As String = Await UnzipAsync(filesToUnzip.ToString, outputFolder, zipProgress)

        'If result.ToLower().Contains("error") OrElse result.ToLower().Contains("failed") Then
        '    MessageBox.Show("Unzipping failed: " & result, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        'Else
        '    MessageBox.Show(result, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
        'End If

        'ProgressBar1.Value = 0

    End Sub








    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        Dim aboutText As String =
"VERSION: " & ModuleVersion_Zipper & Environment.NewLine & Environment.NewLine &
"AUTHOR: CoffeeCodeConverter" & Environment.NewLine &
"CREATION Date: 21/06/2025" & Environment.NewLine & Environment.NewLine &
"REQUIREMENTS:" & Environment.NewLine &
".NET Framework 4.5.1 Or higher" & Environment.NewLine &
"System.IO.Compression (built-in)" & Environment.NewLine &
"Windows API Code Pack (for enhanced folder dialogs)" & Environment.NewLine & Environment.NewLine &
"DESCRIPTION:" & Environment.NewLine &
"A comprehensive, asynchronous Zipping and Unzipping Module that simplifies file compression and extraction" & Environment.NewLine &
"with full progress reporting and robust error handling." & Environment.NewLine &
"Includes built-in customizable fallback dialogs for file and folder selection," & Environment.NewLine &
"enabling seamless user interaction across different UI environments." & Environment.NewLine & Environment.NewLine &
"KEY FEATURES:" & Environment.NewLine &
"- Asynchronous zipping and unzipping with real-time progress percentage updates" & Environment.NewLine &
"- Supports selection of files and folders for compression, with optional dialog fallback if no parameters provided" & Environment.NewLine &
"- Handles both file and directory compression, preserving folder structure during extraction" & Environment.NewLine &
"- Gracefully manages errors and cancellation scenarios with clear status messages" & Environment.NewLine &
"- Integrated custom file/folder dialog support for easy file system browsing and selection" & Environment.NewLine &
"- Optional callback support for post-operation hooks, ideal for UI updates or logging" & Environment.NewLine &
"- Designed for effortless integration into any .NET project requiring reliable archive management"

        MessageBox.Show(aboutText, "About Async Zip Module", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub





    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing

    End Sub

    Private Sub TextBox_Output_Filename_TextChanged(sender As Object, e As EventArgs) Handles TextBox_Output_Filename.TextChanged

    End Sub

    Private Sub TextBox_Output_Filename_Validating(sender As Object, e As CancelEventArgs) Handles TextBox_Output_Filename.Validating
        ValidateZipFilename(TextBox_Output_Filename)
    End Sub


    Private Sub ValidateZipFilename(ByRef passedTextBox As System.Windows.Forms.TextBox)
        Dim filename As String = passedTextBox.Text.Trim()

        ' If the filename doesn't end with .zip, fix it
        If Not filename.ToLower().EndsWith(".zip") Then
            Dim withoutExt = Path.Combine(
            Path.GetDirectoryName(filename),
            Path.GetFileNameWithoutExtension(filename)
        )
            filename = withoutExt & ".zip"
        End If

        passedTextBox.Text = filename
    End Sub



End Class
